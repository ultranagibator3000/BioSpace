import 'package:flutter/material.dart';

class MonitoringPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Monitoring",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.black, Colors.deepPurple],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: ListView(
            children: [
              buildCharacteristic("Oxygen Level (O2)", "20.9%", "Level: Optimal"),
              buildCharacteristic("Carbon Dioxide Level (CO2)", "0.04%", "Level: Normal"),
              buildCharacteristic("Humidity", "60%", "Level: Optimal"),
              buildCharacteristic("Pressure", "100 kPa", "Level: Normal"),
              buildCharacteristic("Temperature", "24°C", "Level: Ideal"),
              buildCharacteristic("Light Intensity", "150 µmol/m²/s", "Level: Optimal"),
              buildCharacteristic("Air Speed", "1.5 m/s", "Level: Normal"),
              buildCharacteristic("Soil pH", "6.5", "Level: Normal"),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCharacteristic(String label, String value, String level) {
    return Card(
      color: Colors.deepPurpleAccent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.lightBlueAccent,
              ),
            ),
            SizedBox(width: 10),
            Text(
              level,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.normal,
                color: Colors.grey[300],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
