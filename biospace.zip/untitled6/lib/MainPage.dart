import 'package:flutter/material.dart';
import 'analytic.dart';
import 'monitoring.dart';
import 'camera_page.dart' as camera;
import 'ancam.dart' as ancam;
import 'package:camera/camera.dart';

class MainPage extends StatelessWidget {
  final List<CameraDescription> cameras;

  const MainPage({Key? key, required this.cameras}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Main Menu",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.black, Colors.deepPurple],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 50),
            Container(
              padding: EdgeInsets.all(16),
              margin: EdgeInsets.only(bottom: 30),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                "Hello, dear user! Here you can press the buttons you need to get information about plants on the plantations.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Spacer(),
            buildButton(context, "Surveillance Camera", Icons.camera, () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => camera.CameraPage()),
              );
            }),
            SizedBox(height: 30),
            buildButton(context, "Analysis Camera", Icons.camera_alt, () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ancam.AnCam(cameras: cameras)),
              );
            }),
            SizedBox(height: 30),
            buildButton(context, "System Monitoring Mode", Icons.monitor, () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MonitoringPage()),
              );
            }),
            SizedBox(height: 30),
            buildButton(context, "Analytics", Icons.analytics, () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Analytic()),
              );
            }),
            Spacer(flex: 2),
          ],
        ),
      ),
    );
  }

  Widget buildButton(BuildContext context, String label, IconData icon, VoidCallback onPressed) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 30, color: Colors.white),
      label: Text(
        label,
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
        backgroundColor: Colors.lightBlueAccent,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }
}
